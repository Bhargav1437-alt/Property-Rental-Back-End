﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HouseRentalApplication.Data;
using HouseRentalApplication.Models.DTOs;
using AutoMapper;
using Microsoft.AspNetCore.Cors;
using HouseRentalApplication.Models.Entity;

namespace HouseRentalApplication.Controllers
{
    [EnableCors("AllowAll")]
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;

        public NotificationsController(ApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        // GET: api/Notifications
        [HttpGet]
        public async Task<ActionResult<IEnumerable<NotificationDto>>> GetNotifications()
        {
            var notifications = await _context.Notifications
                .Select(n => new NotificationDto
                {
                    NotificationId = n.NotificationId,
                    LandLordId = n.LandLordId,
                    Name = n.Name,
                    Email = n.Email,
                    Phone = n.Phone,
                    AdditionalComments = n.AdditionalComments,
                    ReceivedDateTime = n.ReceivedDateTime
                })
                .ToListAsync();

            return Ok(notifications);
        }

        // POST: api/Notifications
        [HttpPost]
        public async Task<ActionResult<NotificationDto>> CreateNotification([FromBody] NotificationDto notificationDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var notification = new NotificationDto
            {
                LandLordId = notificationDto.LandLordId,
                Name = notificationDto.Name,
                Email = notificationDto.Email,
                Phone = notificationDto.Phone,
                AdditionalComments = notificationDto.AdditionalComments,
                ReceivedDateTime = DateTime.UtcNow.AddHours(5).AddMinutes(30)
            };

            // Convert DTO to entity before saving
            var notificationEntity = _mapper.Map<Notification>(notification);
            _context.Notifications.Add(notificationEntity);
            await _context.SaveChangesAsync();

            // Return the newly created notification as DTO
            var createdNotificationDto = _mapper.Map<NotificationDto>(notificationEntity);
            return CreatedAtAction(nameof(GetNotifications), new { id = createdNotificationDto.NotificationId }, createdNotificationDto);
        }

        // GET: api/Notifications/landlord/{landLordId}
        [HttpGet("landlord/{landLordId}")]
        public async Task<ActionResult<IEnumerable<NotificationDto>>> GetNotificationsByLandLordId(int landLordId)
        {
            var notifications = await _context.Notifications
                .Where(n => n.LandLordId == landLordId)
                .Select(n => new NotificationDto
                {
                    NotificationId = n.NotificationId,
                    LandLordId = n.LandLordId,
                    Name = n.Name,
                    Email = n.Email,
                    Phone = n.Phone,
                    AdditionalComments = n.AdditionalComments,
                    ReceivedDateTime = n.ReceivedDateTime
                })
                .ToListAsync();

            if (notifications == null || notifications.Count == 0)
            {
                return NotFound(new { message = $"No notifications found for LandLordId {landLordId}." });
            }

            return Ok(notifications);
        }

    }
}
