﻿namespace HouseRentalApplication.Models.Entity
{
    public class Property
    {
        public int PropertyId { get; set; }
        public string? Title { get; set; }
        public string? Address { get; set; }
        public decimal? RentPrice { get; set; }
        public string? PropertyType { get; set; } // apartment, house, etc.
        public string? Description { get; set; }
        public string? Status { get; set; } // available, rented
        public int Bedrooms { get; set; }
        // Foreign key
        public int LandlordId { get; set; } // Keep as int
        public bool ParkingIncluded { get; set; } // Indicates if parking is included
        public bool PetsAllowed { get; set; } // Indicates if pets are allowed
        public string? Furnished { get; set; } // Level of furnishing (None, Semi, Fully)
        
        // Navigation properties
        public User? Landlord { get; set; }
        public ICollection<Rental>? Rentals { get; set; } // Make optional
    }
}
