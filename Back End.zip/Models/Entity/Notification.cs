﻿namespace HouseRentalApplication.Models.Entity
{
    public class Notification
    {
        public int NotificationId { get; set; }
        public int LandLordId { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Phone { get; set; }
        public string? AdditionalComments { get; set; }
        public DateTime? ReceivedDateTime { get; set; }

    }
}
