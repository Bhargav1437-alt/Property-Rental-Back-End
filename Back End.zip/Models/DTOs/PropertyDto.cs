﻿namespace HouseRentalApplication.Models.DTOs
{
    public class PropertyDto
    {
        public int? PropertyId { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public string? Address { get; set; }
        public decimal? RentPrice { get; set; }
        public string? PropertyType { get; set; } // apartment, house, etc.
        public string? Status { get; set; } // available, rented
        public int? Bedrooms { get; set; }
        public int? LandlordId { get; set; } // Foreign key
        public bool? ParkingIncluded { get; set; } // Indicates if parking is included
        public bool? PetsAllowed { get; set; } // Indicates if pets are allowed
        public string? Furnished { get; set; } // Level of furnishing (None, Semi, Fully)
    }
}
